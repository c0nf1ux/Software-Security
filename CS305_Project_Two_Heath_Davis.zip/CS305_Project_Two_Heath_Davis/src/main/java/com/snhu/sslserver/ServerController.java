package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@RestController
public class ServerController {
    
    @GetMapping("/hash")
    public String getChecksum() {
        String data = "Hello World Check Sum! - Heath Davis";
        String algorithm = "SHA-256";
        
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return String.format(
                "<h2>Artemis Financial - Secure Checksum Verification</h2>" +
                "<p><strong>Data:</strong> %s</p>" +
                "<p><strong>Student:</strong> Heath Davis</p>" +
                "<p><strong>Algorithm:</strong> %s</p>" +
                "<p><strong>Checksum:</strong> <code>%s</code></p>" +
                "<p><strong>Connection:</strong> Secured with SSL/TLS</p>", 
                data, algorithm, hexString.toString()
            );
            
        } catch (NoSuchAlgorithmException e) {
            return "<h2>Error</h2><p>Error generating checksum: " + e.getMessage() + "</p>";
        }
    }
}
